/* 
 * File:   
 * Author: 
 * Created on 
 * Purpose:  Creation of Template to be used for all
 *           future projects
 */

//System Libraries
#include <iostream>  //Input/Output Library
using namespace std;

//User Libraries

//Global Constants, no Global Variables are allowed



//Math/Physics/Conversions/Higher Dimensions - i.e. PI, e, etc...

//Function Prototypes

//Execution Begins Here!
int main(int argc, char** argv) {
  
    
    //Declare Variables
    float weight,height,age,hatS,jakS,
            wSize;//norm measurement
    float jakSS,  //if your old and wide
          wWSize; //if your old and wide
    float futWaste; //To make you feel worst
    float futJak;   //To make you feel better
    char choice;
    
     //equations
           
    cout << "Enter height(inches):\n";
    cin >> height;
    cout << "\n";
    cout << "Enter Weight(pounds):\n";
    cin >> weight;
    cout << "\n";
    cout << "Enter age:\n";
    cin >> age;
    if(age<30)
    {  
       cout.setf(ios::showpoint);
       cout.setf(ios::fixed);
       cout.precision(1); 
       hatS=(weight/height*2.9);
       jakS=(height*weight/288);
       futJak=(height*weight/288);
       wSize=(weight/5.7);
       futWaste=(weight/5.7)+0.3;
       cout << "Hat size = "<<hatS<<endl;
       cout << "Jacket size = "<<jakS<<endl;
       cout << "Jacket size in 10 years = "<<futJak<<endl;
       cout << "Waist size = "<<wSize<<endl;
       cout << "Waist size in 10 years = "<<futWaste<<endl;
    }
    if(age>=30)
    {
        cout.setf(ios::showpoint);
        cout.setf(ios::fixed);
        cout.precision(1);
        hatS=(weight/height*2.9);
        jakSS=(height*weight/288)+(1/8);
        wWSize=(weight/5.7)+(1/10);
        futWaste=(weight/5.7)+0.5;
        cout << "Hat size = "<<hatS<<endl;
        cout << "Jacket size = "<<jakSS<<endl;
        cout << "Jacket size in 10 years = "<<futJak<<endl;
        cout << "Waist size = "<<wWSize<<endl;
        cout << "Waist size in 10 years = "<<futWaste<<endl;
    }
    cout <<"\n";
    cout << "Run again:";
    cin >> choice;
    cout << "\n";
    if(choice=='n'||choice=='N')
    {
        
    }
    if(choice=='y'||choice=='Y')
    {
        cout.setf(ios::showpoint);
        cout.setf(ios::fixed);
        cout.precision(1);
        cout << "Enter height(inches):\n";
        cin >> height;
        cout << "\n";
        cout << "Enter Weight(pounds):\n";
        cin >> weight;
        cout << "\n";
        cout << "Enter age:\n";
        cin >> age;
        if(age<30)
    {  
       cout.setf(ios::showpoint);
       cout.setf(ios::fixed);
       cout.precision(1); 
       hatS=(weight/height*2.9);
       jakS=(height*weight/288);
       futJak=(height*weight/288);
       wSize=(weight/5.7);
       futWaste=(weight/5.7)+0.3;
       cout << "Hat size = "<<hatS<<endl;
       cout << "Jacket size = "<<jakS<<endl;
       cout << "Jacket size in 10 years = "<<futJak<<endl;
       cout << "Waist size = "<<wSize<<endl;
       cout << "Waist size in 10 years = "<<futWaste<<endl;
        }
    if(age>=30)
    {
        cout.setf(ios::showpoint);
        cout.setf(ios::fixed);
        cout.precision(1);
        hatS=(weight/height*2.9);
        jakSS=(height*weight/288)+(1/8);
        futJak=(height*weight/288)+(1/8)+(0.1);
        wWSize=(weight/5.7)+(1/10);
        futWaste=(weight/5.7)+0.5;
        cout << "Hat size = "<<hatS<<endl;
        cout << "Jacket size = "<<jakSS<<endl;
        cout << "Jacket size in 10 years = "<<futJak<<endl;
        cout << "Waist size = "<<wWSize<<endl;
        cout << "Waist size in 10 years = "<<futWaste<<endl;
    }
        cout <<"\n";
        cout << "Run again:";
        cin >> choice;
        cout << "\n";
    } 
    
    
    //Initialize or input i.e. set variable values
    
    //Map inputs -> outputs
    
    //Display the outputs

    //Exit stage right or left!
    return 0;
}