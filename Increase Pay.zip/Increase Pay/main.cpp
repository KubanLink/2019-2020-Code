/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   main.cpp
 * Author: corbinyoung
 *
 * Created on January 16, 2020, 1:08 PM
 */

#include <cstdlib>
#include <iostream>
#include <iomanip>


using namespace std;

/*
 * 
 */
int main(int argc, char** argv) 
{
    //Declare variables or constants here
    //7 characters or less
    float PercInc=.076;
    float DtoY;
    float MtoY=12;
    float TotMInc=6;
    
    
    
    //Initialize or input data here

            
    
    
    //Display initial conditions, headings here
    float retroP;
    float aSal;
    retroP=(aSal*PercInc*TotMInc/MtoY);
    cout << "Input the previous annual salary.\n";
    cin >> aSal;
    cout << "Retroactive pay    = $ "<< retroP;
    
    
            
    //Process inputs  - map to outputs here
    
    //Format and display outputs here
    
    //Clean up allocated memory here
    
    //Exit stage left

    return 0;
}

