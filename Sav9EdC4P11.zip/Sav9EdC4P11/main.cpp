/* 
 * File:   
 * Author: 
 * Created on 
 * Purpose:  Creation of Template to be used for all
 *           future projects
 */

//System Libraries
#include <iostream>
#include <iomanip>//Input/Output Library
using namespace std;

//User Libraries

//Global Constants, no Global Variables are allowed



//Math/Physics/Conversions/Higher Dimensions - i.e. PI, e, etc...

//Function Prototypes

//Execution Begins Here!
int main(int argc, char** argv) {
  
    
    //Declare Variables
    float weight,height,age,hatS,jakS,
            wSize;//norm measurement
    float jakSS,  //if your old and wide
          wWSize; //if your old and wide
    float x=1;
    char choice;
    
     //equations
           
    cout << "Enter height(inches):\n";
    cin >> height;
    cout << "\n";
    cout << "Enter Weight(pounds):\n";
    cin >> weight;
    cout << "\n";
    cout << "Enter age:\n";
    cin >> age;
    if(age<30)
    {  
       cout.setf(ios::showpoint);
       cout.setf(ios::fixed);
       cout.precision(1); 
       hatS=(weight/height*2.9);
       jakS=(height*weight/288);
       wSize=(weight/5.7);
       cout << "Hat size = "<<hatS<<endl;
       cout << "Jacket size = "<<jakS<<endl;
       cout << "Waist size = "<<wSize<<endl;
    }
    if(age>=30)
    {
        cout.setf(ios::showpoint);
        cout.setf(ios::fixed);
        cout.precision(1);
        hatS=(weight/height*2.9);
        jakSS=(height*weight/288)+(x/8);
        wWSize=(weight/5.7);
        int i;
        float x=1;
        //float wWSIze2;
        for(i=30; i<=age;i=i+2)
        {
            
            wWSize=wWSize+(x/10);
        }
        cout << "Hat size = "<<hatS<<endl;
        cout << "Jacket size = "<<jakSS<<endl;
        cout << "Waist size = "<<wWSize<<endl;
    }
    cout <<"\n";
    cout << "Run again:";
    cin >> choice;
    cout << "\n";
    if(choice=='n'||choice=='N')
    {
        
    }
    if(choice=='y'||choice=='Y')
    {
        cout.setf(ios::showpoint);
        cout.setf(ios::fixed);
        cout.precision(1);
        cout << "Enter height(inches):\n";
        cin >> height;
        cout << "\n";
        cout << "Enter Weight(pounds):\n";
        cin >> weight;
        cout << "\n";
        cout << "Enter age:\n";
        cin >> age;
        cout <<"\n";
         if(age<30)
    {  
       cout.setf(ios::showpoint);
       cout.setf(ios::fixed);
       cout.precision(1); 
       hatS=(weight/height*2.9);
       jakS=(height*weight/288);
       wSize=(weight/5.7);
       cout << "Hat size = "<<hatS<<endl;
       cout << "Jacket size = "<<jakS<<endl;
       cout << "Waist size = "<<wSize<<endl;
    }
    if(age>=30)
    {
        cout.setf(ios::showpoint);
        cout.setf(ios::fixed);
        cout.precision(1);
        hatS=(weight/height*2.9);
        jakSS=(height*weight/288)+(x/8);
        wWSize=(weight/5.7)+(1/10);
            
   
        int i;
        //float wWSIze2;
        float x=1;
        for(i=30; i<=age;i=i+2)
        {
            
            wWSize=wWSize+(x/10);
        }
        cout << "Hat size = "<<hatS<<endl;
        cout << "Jacket size = "<<jakSS<<endl;
        cout << "Waist size = "<<wWSize<<endl;
    }
        cout << "Run again:";
        cin >> choice;
        cout << "\n";
    
    } 
    
    
    //Initialize or input i.e. set variable values
    
    //Map inputs -> outputs
    
    //Display the outputs

    //Exit stage right or left!
    return 0;
}