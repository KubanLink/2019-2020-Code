/* 
 * File:   main.cpp
 * Author: corbinyoung
 *
 * Created on January 19, 2020, 5:11 PM
 *Purpose
 */

#include <cstdlib>
#include <iostream>

using namespace std;

int main() 
{
    const float TAX_RATE = 0.05; // 5% sales tax
    char saleType;//character will be wanting to know
    //to determine if retail or wholesale
    int number;
    float price, total;
    
    cout << "Enter price $:";
    cin >> price;
    cout << "Enter the number purchased.\n";
    cin >> number;
    cout << "Type W if this is a wholesale purchase.\n";
    cout << "Type R if this is a Retail purchase.\n";
    cout << "The press Return.\n";
    
    cin >> saleType;
    
    if((saleType=='W') || (saleType=='w'))  //relational operator
    {
        //Branched statement: *Remember that the local variable will 
        //being destroyed.
        total = price*number;    
    }else if((saleType=='R')||(saleType=='r'))
    {
        float subtotal;
        subtotal=price*number;
        total=subtotal+subtotal*TAX_RATE; 
    }
    else
    {
        cout << "Error in input.\n";
    }
    cout.setf(ios::fixed);
    cout.setf(ios::showpoint);
    cout.precision(2);
    cout << number << "items at $" << price << endl;
    cout << "Total Bill = $" << total;
    if((saleType=='R') || (saleType=='r'))
        cout << "including sales tax.\n";
    
    
    
    return 0;
}

