/* 
 * File:   
 * Author: Corbin Young
 * Created on February 20,2020
 * Purpose: 
 */

//System Libraries
#include <iostream>
using namespace std;

//User Libraries

//Global Constants - No Global Variables
//Only Universal Constants, Math, Physics, Conversions, Higher Dimensions

//Function Prototypes
int bubbleSort(int array [],int start, int end){
    int index;
    int sc=0;
    
    for (int i = end -1; i>0; i--){
        for (index = start; index < i; index++){
            if (array[index] > array[index+1]){
                sc++;
                swap(array[index],array[index+1]);
            }
        }
        
    }
    return sc;
}

int selectionSort (int array[], int start, int end){
    int minIndex, minValue;
    int ss=0;
    
    for(int i = start; i <(end-1); i++){
       minIndex = i;
       minValue = array[i];
       
      for (int index = i + 1; index < end; index++){
          
       if (array[index] < minValue)
        {
            minValue = array[index];
            minIndex = index;
        }
    }
    
    ss++;
    swap(array[minIndex],array[i]);
    
    
    } 
    return ss;
}
   


//Execution Begins Here
int main(int argc, char** argv) {
    //Set Random Number seed
    int arr1 []={
            81,36,37,85,52,70,38,55,31,37,
            27,58,32,40,99,79,92,31,32,64,
            92,35,85,66,27,67,23,11,91,88,
            17,18,71,49,13,82,68,82,23,12
    };
    int arr2 []={
            81,36,37,85,52,70,38,55,31,37,
            27,58,32,40,99,79,92,31,32,64,
            92,35,85,66,27,67,23,11,91,88,
            17,18,71,49,13,82,68,82,23,12
    };
    //Declare Variable Data Types and Constants

    //Initialize Variables
    int sl;//starting 
    int el;//ending
    int sc ;//bubble sort
    int ss = 0;//selection sort
    
    
    
    //Process or map Inputs to Outputs
    
    //Display Outputs
    cout<<"Enter the starting location to sort:"<<endl;
    cin>>sl;
    //first  search
    cout<<"Enter the ending location to sort:"<<endl;
    cin>>el;
    //second search 
    
    
    
    ss = selectionSort (arr1,sl,el);
    
    cout<<"Selection Sort "<<ss<<endl;
    
    sc = bubbleSort(arr2,sl,el);
    cout<<"Bubble Sort "<<sc;

    //Exit stage right!
    return 0;
}