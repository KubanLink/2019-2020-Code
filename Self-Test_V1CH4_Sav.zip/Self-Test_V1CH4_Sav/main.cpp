#include <iostream>
#include <cstdlib>
#include <iomanip>


using namespace std;
char mystery(int firstpar, int secondpar);

int main()
{
    cout << mystery( 10, 9) << "ow\n";

    return 0;
}
char mystery(int firstpar, int secondpar)
{
    if(firstpar>=secondpar)
        return 'W';
    else
        return 'H';
}