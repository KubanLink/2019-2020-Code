/* 
 * File:
 * Author: Corbin Young
 * Date:    January 16, 2020 8:26 PM
 * Purpose: Write a program that determines whether a meeting room is in violation
of fire law regulations regarding the maximum room capacity. The program
will read in the maximum room capacity and the number of people
attending the meeting. If the number of people is less than or equal to the
maximum room capacity, the program announces that it is legal to hold
the meeting and tells how many additional people may legally attend. If
the number of people exceeds the maximum room capacity, the program
announces that the meeting cannot be held as planned due to fire regulations
and tells how many people must be excluded in order to meet the
fire regulations.
Use 7 character or less variable names.
Use only the size integer variables required.
Use only the float data type where necessary, no doubles.
 * Version:
 */

//System Libraries - Post Here
#include <iostream>
#include <iomanip>
#include <cstdlib>

using namespace std;

//User Libraries - Post Here

//Global Constants - Post Here
//Only Universal Physics/Math/Conversions found here
//No Global Variables
//Higher Dimension arrays requiring definition prior to prototype only.

//Function Prototypes - Post Here

//Execution Begins Here
int main() 
{
    
    //Declare variables or constants here
    //7 characters or less
    
    //Number of people attending your meeting
    float numPeep, MaxCap;
    cout << "Input the Maximum room capacity and the number of people\n";
    cin >> MaxCap >> numPeep;
    
    if(numPeep<MaxCap)
    {
       cout << "It is legal to hold the meeting";
       cout << "This many additional people may attend ";
       float AddiP;
       AddiP=MaxCap-numPeep;
       cout << AddiP;
    }
    else
    {
        cout << "Meeting cannot be held.\n";
        float NegPeep;
        NegPeep=numPeep-MaxCap;
        cout << "Reduce number of people by " << NegPeep
                << " to avoid fire violation. ";
    }
    
    
    //Initialize or input data here

   
    //Display initial conditions, headings here


    
    
    //Process inputs  - map to outputs here
    
    //Format and display outputs here
    
    //Clean up allocated memory here   
    //Exit stage left
    return 0;
}