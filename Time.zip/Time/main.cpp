/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   main.cpp
 * Author: corbinyoung
 *
 * Created on October 1, 2019, 8:54 PM
 */

#include <cstdlib>
#include <iostream>

using namespace std;

/*
 * 
 */
int main() {

    const int sec_to_min=60;
    const int sec_to_hour=3600;
    const int sec_to_day=86400;
    
    // User must declare an amount in seconds
    int seconds, min, hour, day;
    cout << " Input a number of seconds: ";
    cin >>seconds;
    
    //add restriction
    if(seconds<0){
    cout << "The number you entered is invalid. ";
    cout << "Enter number a positive integer " << endl;
    return 1;
    }
    
    if (seconds <60)
        cout << seconds << " seconds." << endl;
    
    if(seconds>=60 && seconds<3600)
    {       
    cout << " There is this many minutes in that many seconds ";
     min = seconds/sec_to_min;
     cout << min << " minutes";
    }
    
    if(seconds>=3600 && seconds < 86400)   
    {
    cout <<" There is this many hours in that many seconds: ";
    hour = seconds/sec_to_hour;
    cout << hour << " hours";
    }
   
    
    if(seconds>=86400)
    {
    cout <<" There is this many seconds in a day: ";
    day = seconds/sec_to_day;
    cout << day << " days.";
    }
    
    return 0;
}

