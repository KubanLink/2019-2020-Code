/*
 * File:main.cpp
 * Author:Corbin Young
 * Created on January 6, 2020, 12:23pm
 * Purpose : C++ Template to be copied and utilized 
 * for homework, projects, exams
 */

//System Libraries
#include <iostream>//For Input and Output
#include <iomanip> //Setw,Setprecision
#include <cstdlib>//Random number Generator
#include <string>
#include <cstring>
#include <vector>
using namespace std;

//User Libraries 

//Global Constants - No Global Variables
//Only Universal COnstants, Math, Physics, Conversions

//Function Prototypes

// Execution begins Here
int main() 
{
    //Set Random Number seed

    //Declare Variables Data Types and constants
    string phrase;
    string adjective("fried"),noun("ants");
    string wish="Bon apetit!";
    
    
    //Initialize Variables
    phrase="I love "+adjective+" "+noun+"!";
    
    //Process or map Inputs to outputs
    
    //Display outputs
    cout << phrase <<endl
            <<wish<<endl;
    //Exit stage right!
    return 0;
}
