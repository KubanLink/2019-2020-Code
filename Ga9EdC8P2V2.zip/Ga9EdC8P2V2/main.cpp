/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   main.cpp
 * Author: corbinyoung
 *
 * Created on February 10, 2020, 9:11 PM
 */


//System Libraries
#include <iostream>
using namespace std;

//User Libraries

//Global Constants - No Global Variables
//Only Universal Constants, Math, Physics, Conversions, Higher Dimensions

//Function Prototypes
int linearSearch (int array[],int size, int Usin){//linear searh function
    bool win = false;//win bool
    
    
    
    
    
    for (int i = 0; i < size; i++)//for loop to search for winning number and output that user won
        if (Usin == array[i]){
        cout<<"Congratulations you have won!";
        win = true;
        }
        
       if (!win) cout<<"No winning numbers.";//if bool remains false output no winning numbers
        
        
        
        
       
}


//Execution Begins Here
int main(int argc, char** argv) {
    //Set Random Number seed
    
    //Declare Variable Data Types and Constants
    int tnum [10] = {13579,26791,26792,33445,55555,62483,77777,79422,85647,93121};//user selected numbers
    int wnum; //winning number
    
    //Initialize Variables
    
    //Process or map Inputs to Outputs
    
    //Display Outputs
    cout<<"Enter the winning number:"<<endl;
    cin>>wnum;//winning number input
    
    linearSearch(tnum,10,wnum);
    
    
    
    //Exit stage right!
    return 0;
}
