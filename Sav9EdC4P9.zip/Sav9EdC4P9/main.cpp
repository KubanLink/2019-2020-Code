/* 
 * File:   
 * Author: 
 * Created on 
 * Purpose:  Creation of Template to be used for all
 *           future projects
 */

//System Libraries
#include <iostream> 
#include <iomanip>//Input/Output Library
using namespace std;

//User Libraries

//Global Constants, no Global Variables are allowed
//Math/Physics/Conversions/Higher Dimensions - i.e. PI, e, etc...

//Function Prototypes

//Execution Begins Here!
int main(int argc, char** argv) {
  
    //Declare Variables
    float num1, num2, num3;
    //Initialize or input i.e. set variable values
    cout << "Enter first number:\n";
    cin >> num1;
    cout << "\n";
    cout << "Enter Second number:\n";
    cin >> num2;
    cout << "\n";
    cout << "Enter third number:\n";
    cin >> num3;
    cout << "\n";
    //Map inputs -> output
    if(num1>num2)
    {
        cout.setf(ios::showpoint);
                cout.setf(ios::fixed);
                cout.precision(1);
        cout << "Largest number from two parameter function:\n";
        cout << num1 << endl;
        cout << "\n";
    }
    if(num2>num1)
    {
        cout.setf(ios::showpoint);
                cout.setf(ios::fixed);
                cout.precision(1);
        cout << "Largest number from two parameter function:\n";
        cout << num2 << endl;
        cout << "\n";
    }
    if(num1>num2&&num1>num3)
    {
        cout.setf(ios::showpoint);
        cout.setf(ios::fixed);
        cout.precision(1);
        cout << "Largest number form three parameter fucntion:\n";
        cout << num1<<endl;
        
    }
        if(num2>num1&&num2>num3)
        
        {
            cout.setf(ios::showpoint);
                cout.setf(ios::fixed);
                cout.precision(1);
            cout << "Largest number from three parameter function:\n";
            cout << num2<<endl;
            
        }
            if(num3>num2&&num3>num1)
            {
                cout.setf(ios::showpoint);
                cout.setf(ios::fixed);
                cout.precision(1);
                cout << "Largest number from three parameter function:\n";
                cout << num3<< endl;
                
            }
    //Display the outputs

    //Exit stage right or left!
    return 0;
}