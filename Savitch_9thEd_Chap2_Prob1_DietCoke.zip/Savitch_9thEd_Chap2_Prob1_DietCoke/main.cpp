/* 
 * File:Diet Coke
 * Author: Corbin Young
 * Date: January 18, 2020 8:30 PM
 * Purpose: To calculate the dream weight while having a craving of consuming diet coke. 
 * Version:
 */

//System Libraries - Post Here
#include <iostream>
#include <iomanip>
using namespace std;

//User Libraries - Post Here

//Global Constants - Post Here
//Only Universal Physics/Math/Conversions found here
//No Global Variables
//Higher Dimension arrays requiring definition prior to prototype only.

//Function Prototypes - Post Here

//Execution Begins Here
int main(int argc, char** argv) {
    float wDsrd; //Desired Weight
    float mMouse; //mass of mMouse
    float mKmse;  //grams to Kill mMouse
    float mSoda;  //grams of soda 
    float cnt; //Concentration in mSoda
    int nCans;      //Amount of Cans of Soda
    const float CNVGRMS= 453.592;   //Conversion of grams to weigh of pounds
    
    //Declare Variable Data Types and Constants
    wDsrd=200;
    mMouse = 35; //35 grams
    mKmse = 5;    //5 grams
    mSoda = 350;  //350 grams 
    cnt = 1e-3f; //.001 Concentration
    
    //Initialize Variables
    cout << "Program to calculate the limit of Soda Pop Consumption.\n";
    cout << "Input the desired dieters weight in lbs.\n";
    cin  >> wDsrd;
    nCans =(wDsrd*CNVGRMS*mKmse)/(mMouse*mSoda*cnt);
    cout << "The maximum number of soda pop cans\n";
    cout << "which can be consumed is "<< nCans << " cans";
    
    
    //Process or map Inputs to Outputs
    
    //Display Outputs

    //Exit stage right!
    return 0;
}