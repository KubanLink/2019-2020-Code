/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   main.cpp
 * Author: corbinyoung
 *
 * Created on February 15, 2020, 6:43 PM
 */

#include <cstdlib>
#include <cstring>
#include <iostream>
#include <string>

using namespace std;

/*
 * 
 */
int main(int argc, char** argv) 
{
    int arraySize=10;
    int *a;
    a=new int[arraySize];
    int i;
    for(i=0;i<arraySize;i++)
        (*a+i)=i;
    while(*a<9)
    {
        a++;
        cout << *a <<" ";
    }    
    cout << endl;
    return 0;
}

