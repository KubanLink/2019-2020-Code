#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Thu May 14 18:06:56 2020

@author: corbinyoung
"""

def chem():
    print('enter C for celsisu or F for farranheit')
    x=input()
    Now1=x.strip()
    if Now1=='C':
        y1=input('i will convert celcius to faranheit\n')
        Cel=(float(y1)*9/5+32)
        q=round(Cel,1)
        print(y1+" Celsius ==",Cel," Farenheit")
    elif Now1=='F':
        y2=input('I will convert farenheit to celsius\n')
        Far=(float(y2)-32/(9/5))
        q=round(Far,1)
        print(y2+" Farenheit ==",q," celsius")
        
chem()
chem()