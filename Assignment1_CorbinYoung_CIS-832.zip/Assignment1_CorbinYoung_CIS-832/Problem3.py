#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Thu May 14 18:20:32 2020

@author: corbinyoung
"""

#Creating a dicitionary
d={'Negative':'Positive','Wake Up':'Do Chemistry','Go to Sleep':'Dream Mad Science'}
def D(*pargs,**kwargs):
    
    #Create default or Oveeerview of Dict.
    print(kwargs.setdefault('Negative, Wake Up, Go to Sleep','Positive, Do Chemistry, Dream Mad Science'))
    #Print Keys?
    print(kwargs.keys())
    #Print Key Values?
    print(kwargs.values())
    return None


    
D(d) #Due to default you can understand what is inside D
D(d.keys,d.values)  #Order is never understood until you utilize Defaults.

#print(type(d))
print(d.items())
#q=iter(d.keys)