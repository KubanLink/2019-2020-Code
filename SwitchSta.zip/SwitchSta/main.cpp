/*
 * File:main.cpp
 * Author:Dr.Mark E. Lehr
 * Created on January 6, 2020, 12:23pm
 * Purpose : C++ Template to be copied and utilized 
 * for homework, projects, exams
 */

//System Libraries
#include <iostream>
#include <iomanip>
#include <ctime>
#include <cstdlib>
#include <string>
#include <algorithm>
using namespace std;

//User Libraries 

//Global Constants - No Global Variables


//Only Universal COnstants, Math, Physics, Conversions

//Function Prototypes

// Execution begins Here
int main() 
{
    srand(static_cast<unsigned int>(time(0)));
    //Declare Variables Data Types and constants
    unsigned char grade, score;
    
    //Initialize Variables
    score=rand()%51+50;//[50,100]
    //Process or map Inputs to outputs
    switch(score/10){
            case 10:
            case 9:grade='A';break;
            case 8:grade='B';break;
            case 7:grade='C';break;
            case 6:grade='D';break;
            case 5:grade='F';break;
    }
    cout << "With a score of "<<
            static_cast<int>(score)<< " the grade = ";
    cout << grade;
    //Exit stage right!
    return 0;
}

