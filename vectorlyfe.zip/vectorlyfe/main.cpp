/*
 * File:main.cpp
 * Author:Corbin Young
 * Created on February 5, 2020, 12:23pm
 * Purpose : C++ Template to be copied and utilized 
 * for homework, projects, exams
 */

//System Libraries
#include <iostream>
#include <cstdlib>
#include <iomanip>
#include <string>//to make phrases
using namespace std;

//User Libraries 

//Global Constants - No Global Variables
//Only Universal COnstants, Math, Physics, Conversions

//Function Prototypes
char Begin();
bool isEven();
float cash(float, float);
int SendIt(int &);
int ChewsNm(int*);
// Execution begins Here
int main() 
{
//Set Random Number seed
    srand(static_cast<unsigned int>(time(0))); 
    //Declare Variables Data Types and constants
    int *num;
    int table,red,black,green;
    int number,value;
    float money;
    float chipV;
    char option,    //Enter into rules
            q;//quits to home screen
    
            
    
    Begin();
    ChewsNm(num);
    if(ChewsNm(num)==SendIt(number))
        cout << "You win";
    else
        cout << "You lose";
    
        
    //Initialize Variables

    //Process or map Inputs to outputs
    
    //Display outputs
    
    //Exit stage right!
return 0;
}
int ChewsNm(int val[])
{
    cout << "THE BALL IS SPINNING ...\n";
    cout << "Enter [10] Values";
    for(int i=0; i<10;i++)
    {
    cin >> val[i];
    }
    return val[10];
}
char Begin(){
    char option;//Option for switching out of main screen
    char pause;//Pauses for User to Read Rules.
    cout << setw(5)<<" * WELCOME TO ROULETTE!*\n";
    cout << "Option 1: To Play Inside\n";
    cout << "Option 2: To Play Outside\n";
    cin >>option;
    switch(option)
    {
            case '1':
                cout << setw(5) << "Rules for Option 1:";
                cout <<setw(5)<<"-----------------------------";
                cout << "You may choose up to [10] numbers\n";
                cout << "If you would like to quit select 'q'\n";
                cout << "after the round";
                cout << "Press [ENTER OR RETURN] to continue";
                pause=cin.get();
                cin.get(pause);
                break;
            case '2':
                cout << setw(5) << "Rules for Option 2:";
                cout <<setw(5)<<"-----------------------------";
                cout << "Choose Even or Odd\n";
                cout << "Enter (e) for even\n";
                cout << "Enter (o) for odd\n";
                cout << "If you would like to quit select 'q'\n";
                cout << "after the round";
                cout << "Press [ENTER OR RETURN] to continue";
                pause=cin.get();
                cin.get(pause);
                break;
    }
}
bool isEven(int val)
{
    bool status;
    
    if(val %2==0)    //The number is even if there is no remainder.
        status=true;
    else
        status=false;   //Otherwise, the number is odd.
    return status;
}
int SendIt(int &a)
{
    a=rand()%1+1/36;
    return a;
}
float cash(float c, float Chip )
{
    
    
    cout << "Enter amount of Cash You would\n";
    cout << "Like to Play With: ";
    cin >> c;
    cout <<"There are 5 different Chip Values:\n"
            <<"1's, 5's, 25's, 100's\n";
    cout << "Enter a Chip Value: ";
    cin >> Chip;
}

