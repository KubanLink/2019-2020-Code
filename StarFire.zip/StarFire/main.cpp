/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   main.cpp
 * Author: corbinyoung
 *
 * Created on February 1, 2020, 4:39 PM
 */

#include <cstdlib>
#include <iostream>
#include <cstdlib>

using namespace std;


int main(int argc, char** argv) 
{
    int number;
    char star='*';
    cout << "Enter a number";
    cin >> number;
    switch(number){
        case 1: 
            cout << numbe
    }
    return 0;
}
