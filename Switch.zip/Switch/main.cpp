/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   main.cpp
 * Author: corbinyoung
 *
 * Created on October 8, 2019, 11:50 AM
 */

#include <cstdlib>
#include <iostream>

using namespace std;

/*
 * 
 */
int main() {
    int Logic, MobbDeep, 
    
    float iKaylon; 
    cout << "chose an option to learn about kaylon ";
    cout << iKaylon << endl;
    
    ;
    cout << 
    
    
    
    
     

    return 0;
}

