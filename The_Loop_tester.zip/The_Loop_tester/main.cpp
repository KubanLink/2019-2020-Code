/*
 * File:   main.cpp
 * Author: Kuban Link
 *
 * Created on January 19, 2020, 4:42 PM
 */

#include <cstdlib>
#include <iostream>
#include <iomanip>
#include <string>

using namespace std;

int main() 
{
    int temperature;
    char day;
    
    string
    
        Sunday=1, Monday=2, Tuesday=5, Wednesday=8, Thursday=7,
        Friday=3, Saturday=4;
    
    cin >> temperature >> day;
    if((temperature<-10) && (day==Sunday))
        cout << "Stay home.";
    else if(temperature <-10) ||and day!=Sunday
        cout << "Stay home, but call work.";
    else if(temperature <=0)||and temperature>=-10
            cout << " Dress warm.";
    else||temperature>0
            cout << "Work hard and play hard.";
    return 0;
}

