/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   main.cpp
 * Author: corbinyoung
 *
 * Created on January 16, 2020, 1:08 PM
 */


#include <iostream>
#include <iomanip>



using namespace std;

/*
 * 
 */
int main() 
{
    //Declare variables or constants here
    //7 characters or less
    const float PercInc=.076f;
    const short int MtoY=12;
    const short int TotMInc=6;
    
    
    
    //Initialize or input data here
    //Display initial conditions, headings here
    float retroP;   //Retroactive Pay 
    float aSal;     //Current  Salary
    float nSal;     //New Anaual Salary
    float mSal;     //Monthly Anual Salary 

            
    //Process inputs  - map to outputs here
    cout << "Input previous annual salary." <<endl;
    cin >> aSal;
    //Format and display outputs here
    retroP=(aSal*PercInc*TotMInc)/MtoY; //The total retroactive pay
    cout << "Retroactive pay    = $  "<<fixed<<showpoint<< setprecision(2)<< retroP << endl;
    nSal= aSal+(aSal*PercInc);  //The total annual Salary
    cout << "New annual salary  = $" <<nSal << endl;
    mSal=(aSal+aSal*PercInc)/MtoY;  //total montly
    cout << "New monthly salary = $ " << mSal;
    //Clean up allocated memory here
    
    //Exit stage left

    return 0;
}


