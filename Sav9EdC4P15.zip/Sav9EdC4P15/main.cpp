/* 
 * File:   
 * Author: 
 * Created on 
 * Purpose:  Creation of Template to be used for all
 *           future projects
 */

//System Libraries
#include <iostream>
#include <iomanip>
//Input/Output Library
using namespace std;

//User Libraries

//Global Constants, no Global Variables are allowed
const float twink=3.50f;
//Math/Physics/Conversions/Higher Dimensions - i.e. PI, e, etc...

//Function Prototypes

//Execution Begins Here!
int main() 
{    
    //Declare Variables
    float dola,quat,dime,nick,amount,change;
    char coin;
    
    //Initialize or input i.e. set variable values
    
    dola=1.00f;
    quat=0.25f;
    dime=0.10f;
    nick=0.05f;
            
    
    //Map inputs -> outputs
    
    do{
    cout << "List of coins:\n";
    cout << "1. Nickel\n";
    cout << "2.Dime\n";
    cout << "3. Quarter\n";
    cout << "4. Dollar\n";
    cout << "Enter number for coin:\n";
    cin >> coin;
    //loop
        
    //Menu
           switch(coin)
            {
            case '1':

                amount+=nick;
                if(amount<=twink)
                {
                    cout.setf(ios::showpoint);
                    cout.setf(ios::fixed);
                    cout.precision(2);
                cout << "Current amount: $";
                cout << amount;
                cout << "\n";
                }
                
                break;
            case '2':
                amount+=dime;
                if(amount<=twink)
                {
                    cout.setf(ios::showpoint);
                    cout.setf(ios::fixed);
                    cout.precision(2);
                cout << "Current amount: $";
                cout << amount;
                cout << "\n";
                }
                break;
            case'3':
                amount+=quat;
                if(amount<=twink)
                {
                    cout.setf(ios::showpoint);
                    cout.setf(ios::fixed);
                    cout.precision(2);
                cout << "Current amount: $";
                cout << amount;
                cout << "\n";
                }

                break;
            case '4':
                amount+=dola;
                if(amount<=twink)
                {
                    cout.setf(ios::showpoint);
                    cout.setf(ios::fixed);
                    cout.precision(2);
                cout << "Current amount: $";
                cout << amount;
                cout << "\n";
                }
                
                break;
            }
        }while(coin<1||coin>4);

    //Display the outputs

    //Exit stage right or left!
    return 0;
}