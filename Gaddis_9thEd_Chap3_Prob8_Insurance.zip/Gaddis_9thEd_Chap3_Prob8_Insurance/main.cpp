/* 
 * File:   main.cpp
 * Author: Corbin Young
 * Created on January 15, 2020, 1:12PM
 * Purpose: Many financial experts advise that property owners should insure their homes or buildings
for at least 80 percent of the amount it would cost to replace the structure. Write a
program that asks the user to enter the replacement cost of a building and then displays
the minimum amount of insurance he or she should buy for the property. 
 */

//System Libraries
#include <iostream>  //Input/Output Library
using namespace std;

//User Libraries

//Global Constants, no Global Variables are allowed
//Math/Physics/Conversions/Higher Dimensions - i.e. PI, e, etc...

//Function Prototypes

//Execution Begins Here!
int main() {
    float rpIn=0.80;  //The recommended insurance amount should be 80 percent.
    
    
    
    //Declare Variables
    float rCost4P;
    cout << "Enter the replacement costs for Building or Property";
    cin>>rCost4P;
    float minA;
    minA=(rCost4P*rpIn);
    cout << "Recommended insurance price range is = " << minA;
    //Initialize or input i.e. set variable values
    
    //Map inputs -> outputs
    
    //Display the outputs

    //Exit stage right or left!
    return 0;
}