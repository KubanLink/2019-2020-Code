/*
 * File:main.cpp
 * Author:Dr.Mark E. Lehr
 * Created on January 6, 2020, 12:23pm
 * Purpose : C++ Template to be copied and utilized 
 * for homework, projects, exams
 */

//System Libraries
#include <iostream>
#include <iomanip>
#include <ctime>
#include <cstdlib>
#include <string>
#include <algorithm>
using namespace std;

//User Libraries 

//Global Constants - No Global Variables


//Only Universal COnstants, Math, Physics, Conversions

//Function Prototypes

// Execution begins Here
int main() 
{
    srand(static_cast<unsigned int>(time(0)));
    //Declare Variables Data Types and constants
    unsigned char grade, score;
    
    //Initialize Variables
    score=rand()%51+50;//[50,100]
    //Process or map Inputs to outputs
    if(score>=90)grade='A';
    else if(score>=80)grade='B';
    else if(score>=70)grade='C';
    else if(score>=60)grade='D';
    else
        grade ='F';
    //Display outputs
    cout << "With a score of "<<
            static_cast<int>(score)<< " the grade = ";
    cout << grade;
    //Exit stage right!
    return 0;
}

