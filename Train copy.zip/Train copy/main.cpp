#include <iostream>
#include <cstdlib>
#include <iomanip>
using namespace std;

int main() {
   
   int speed, trainmph, distance=0;
    
    cout << "What is the speed of the train:  "; //input for speed
    while (!(cin >>speed) || (speed<0))    // loop for user
    {
        cout << "ERROR: speed must be greater than zero \n";    
        cout << " or less than 310" << endl;        // !warning
    cin.clear();
    cin.ignore(310, '\n');      // prof. Conrads  random restrictions
    }
    cout << "How many hours was your train trip:  ";   //input for trip 
    while(!(cin >> trainmph) || (trainmph<0))   // loop for user                                       
    {                                                
        cout << " ERROR: your train trip must be greater than zero \n ";
        cout << " or less than 146" << endl;    //!warning
    cin.clear();
    cin.ignore(146, '\n');    // restrict longest train ride
    }
    cout << "Hour   Distance Traveled" << endl;
    cout <<"-------------------------" << endl;
    
    for(int i = 0; i < trainmph; i++)
    {
        distance +=speed;
        cout << "  " << (i+1) <<"  "
                << distance
                << endl;
    }
    return 0;
}