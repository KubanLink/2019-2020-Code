/* 
 * File:   Gaddis 9th edition chapter 4, porblem 23
 * Author: Corbin Young
 * Created on January 22, 2020
 * Purpose:This program will calculate the area of a triagnle by receiving input from the input 
 *  in regards to the base and the height of a traignle, circle , and rectangle.
 */

//System Libraries
#include <iostream>
#include <iomanip>
#include <cstdlib>
#include <cmath>
using namespace std;

//User Libraries

//Global Constants - No Global Variables



//Only Universal Constants, Math, Physics, Conversions, Higher Dimensions

//Function Prototypes

//Execution Begins Here
int main(int argc, char** argv) 
{
    //Declare Variable Data Types and Constants
    char menu;
    float radC,L,H,base,height,rectA,cRad,triA;
    
    
    do
    {
        //Display Menu Options for user
        cout << "Geometry Calculator\n";
        cout <<"1. Calculate the Area of a Circle\n";
        cout <<"2. Calculate the Area of a Rectangle\n";
        cout <<"3. Calculate the Area of a Triangle\n";
        cout <<"4. Quit\n";
        cin>>menu;
        switch(menu){
            //Calculate the Area of a circle
            case '1':{
                cout.setf(ios::showpoint);
                cout.setf(ios::fixed);
                cout.precision(1);
                cout << "Enter the radius of the circle:\n";
                cin >> radC;
                
                while(radC>=1)
                {
                    cout << "Invalid entry, Reenter:\n";
                    cin>>radC;
                    cin.clear();
                    cin.ignore(100,'\n');
                    if(radC>1)
                        continue;
                }    
                cRad = M_PI*(radC*radC);
                cout << "The area of the circle is"<<cRad;
                break;}
            case '2':{
                cout.setf(ios::showpoint);
                cout.setf(ios::fixed);
                cout.precision(1);
                
                cout <<"Enter the length of the rectangle:\n";
                cin >> L;
                cout <<"Enter the height of the rectangle:\n";
                cin >> H;
                while(L<=1)
                {
                    cout<< "Invalid entry, Reenter:\n";
                    cin >>L;
                    if(L>=1)
                        continue;
                }
                while(H<=1)
                {
                    cout << "Invalid entry, Reenter:\n";
                    cin >> H;
                    if(H>=1)
                        continue;
                }
                    rectA=L*H;
                    cout << "The area of a rectangle is "<< rectA;

                
                break;}
            case '3':{
                cout.setf(ios::showpoint);
                cout.setf(ios::fixed);
                cout.precision(1);
                cout << "Enter the base of the triangle:\n";
                cin >> base;
                cout << "Enter the height of the triangle:\n";
                cin >> height;
                float triA= base*height*.5;
                while(base<1){
                cout << "Invalid entry, Reenter:\n";
                
                    if(base>=1)
                    continue;
                }
                while(height<=1)
                {
                cout << "Invalid entry, Reenter:\n";
                    if(height>=1)
                    continue;
                }
                cout << "The area of the triangle is\n" << triA;
                break;}
            case '4':
            {
            cout << "End of program\n";
            break;            
            }  
            default:
            cout << "Invalid entry, Reenter:\n";
            cin >> menu;
                
                return(menu);
        }
        }while(menu<1 || menu>4);
        {
        
            cout << "Invalid entry, Reenter:\n";
            cin >> menu;
        }
    //Initialize Variables
    
    //Process or map Inputs to Outputs
    
    //Display Outputs

    //Exit stage right!
    return 0;
}