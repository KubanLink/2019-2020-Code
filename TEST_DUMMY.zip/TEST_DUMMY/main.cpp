//Test Dummy
#include <iostream>
#include <cstdlib>
#include <vector>
#include <cstring>
#include <string>
#include <algorithm>

using namespace std;

int main()
{
    cout << "Hello World";
    cout.width(15);
    cout << "Hey" <<endl;
    
    fin.get(next);
    while(next!=' ')
    return 0;
}