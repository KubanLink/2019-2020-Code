/* 
 * File: Chapter 5 problem 1 of the Gaddis 9th edition.  
 * Author: Corbin Young
 * Created on January 23,2020
 * Purpose:  To count
 */

//System Libraries
#include <iostream>
#include <iomanip>
#include <cstdlib>
#include <string>
using namespace std;

//User Libraries

//Global Constants - No Global Variables
//Only Universal Constants, Math, Physics, Conversions, Higher Dimensions

//Function Prototypes

//Execution Begins Here
int main(int argc, char** argv) 
{
    //string s=arg[1];
    int x=stoi(argv[1]);
    int sum=0;
    
    for(int i=0;i<=x;i++)
    {
        sum=sum+i;
    }
    cout << "Sum= "<<argc[1];
 return 0;  
}
    
    //Declare Variable Data Types and Constants
