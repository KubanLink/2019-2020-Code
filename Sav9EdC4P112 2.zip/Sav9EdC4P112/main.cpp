
#include <iostream>

using namespace std;

int main() {

    float weight,height,age,hatS,jakS,wSize;
    float jakSS,wWSize; 
    char choice;
    float x=1;
    choice='n';
     do
     {
        cout << "Enter height(inches):\n";
        cin >> height;
        cout << "\n";
        cout << "Enter Weight(pounds):\n";
        cin >> weight;
        cout << "\n";
        cout << "Enter age:\n";
        cin >> age;
        cout << "\n";
        if(age<30)
        {  
           cout.setf(ios::showpoint);
           cout.setf(ios::fixed);
           cout.precision(1); 
           hatS=(weight/height*2.9);
           jakS=(height*weight/288);
           wSize=(weight/5.7);
           cout << "Hat size = "<<hatS<<endl;
           cout << "Jacket size = "<<jakS<<endl;
           cout << "Waist size = "<<wSize<<endl;
        }
        else if(age>=30)
        {
            cout.setf(ios::showpoint);
            cout.setf(ios::fixed);
            cout.precision(1);
            hatS=(weight/height*2.9);
            jakSS=(height*weight/288);
            for(int i = 41;i<=age;i = i + 10)
            {
                wWSize = wWSize + (x/8);
            }
            wWSize=(weight/5.7);
            for(int i = 30;i<=age;i = i + 2)
            {
                wWSize = wWSize + (x/10);
            }
            cout << "Hat size = "<<hatS<<endl;
            cout << "Jacket size = "<<jakSS<<endl;
            cout << "Waist size = "<<wWSize<<endl;
        }cout << "\n";
        cout << "Run again:\n";
        cin>>choice;
     }while(choice=='y'||choice=='Y');
     cout << "\n";
     return 0;
}
        